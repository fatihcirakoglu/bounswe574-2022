# SWE-573 Project
This project will be developed as a part of Swe-573 course and will be conducted by applying all software project life cycle steps like below. 

- Requirements elicitation
- Modelling
- Development
- Quality assurance
- Communication
- Presentation
- Documentation
- Planning & tracking
- Version management and automated processes
- Deployment.

## General Features of Application: 
Features will be listed after topic clarification.


## Prerequisites
- Will be defined later.
 
## Clone

- Clone this repository to your local machine using `https://github.com/fatihcirakoglu/swe573project.git`
 
## Build
- Just clone the repo on your Linux environment and run below command in the folder.
 ```

 ```

## Installation

- All the `code` required to get started
```

```

## Setup & Deployment
```

```
## FAQ

```

```

## Support
Reach out to me via email!
email: fatih.cirakoglu@boun.edu.tr



## License

[![License](http://img.shields.io/:license-mit-blue.svg?style=flat-square)](http://badges.mit-license.org)

- **[GNU General Public License v3.0](https://opensource.org/licenses/gpl-license)**
- Copyright 2022 © 

